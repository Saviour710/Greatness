// ====== Global Variables ======
const screens = document.querySelectorAll(".screen");
const navBtns = document.querySelectorAll(".nav-btn");
const bottomNav = document.getElementById("bottom-nav");

let currentUser = null;
let accounts = [];
let lastScrollTop = 0;
let postCounter = 1;

// ====== Helper Functions ======
function showScreen(id) {
  screens.forEach((s) => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

function updateBadge(count) {
  const badge = document.querySelector(".badge");
  badge.textContent = count;
}

// ====== Splash Logic ======
setTimeout(() => {
  showScreen("auth-screen");
}, 2000); // 2s splash screen

// ====== Auth Logic ======
const loginForm = document.getElementById("login-form");
const signupLink = document.getElementById("signup-link");

loginForm.addEventListener("submit", (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;

  if (email && password) {
    currentUser = { email, password };
    accounts.push(currentUser);
    showScreen("home-screen");
  } else {
    alert("Please enter email and password");
  }
});

signupLink.addEventListener("click", (e) => {
  e.preventDefault();
  alert("Signup flow coming soon (Firebase later)");
});

document.querySelector(".forgot-password a").addEventListener("click", (e) => {
  e.preventDefault();
  alert("Password reset feature will be added with Firebase.");
});

// ====== Navigation Logic ======
navBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    navBtns.forEach((b) => b.classList.remove("active"));
    btn.classList.add("active");

    if (btn.id === "nav-home") showScreen("home-screen");
    if (btn.id === "nav-search") showScreen("search-screen");
    if (btn.id === "nav-notifications") showScreen("notifications-screen");
    if (btn.id === "nav-profile") showScreen("profile-screen");
  });
});

// ====== Scroll Hide Nav ======
const feed = document.querySelector(".feed");
feed.addEventListener("scroll", () => {
  let st = feed.scrollTop;
  if (st > lastScrollTop) {
    bottomNav.classList.add("hide-nav"); // hide on scroll down
  } else {
    bottomNav.classList.remove("hide-nav"); // show on scroll up
  }
  lastScrollTop = st <= 0 ? 0 : st;
});

// ====== Post Creation ======
const postBtn = document.getElementById("post-btn");
const feedContainer = document.querySelector(".feed");

postBtn.addEventListener("click", () => {
  const newPost = document.createElement("div");
  newPost.classList.add("post");
  newPost.innerHTML = `
    <p>New post #${postCounter} by ${currentUser?.email || "Guest"}</p>
    <hr />
  `;
  feedContainer.prepend(newPost);
  postCounter++;

  // add dummy notification
  updateBadge(postCounter - 1);
});

// ====== Account Switching ======
const switchAccountBtn = document.getElementById("switch-account");
switchAccountBtn.addEventListener("click", () => {
  if (accounts.length > 1) {
    let idx = accounts.indexOf(currentUser);
    currentUser = accounts[(idx + 1) % accounts.length];
    alert(`Switched to ${currentUser.email}`);
  } else {
    alert("Only one account available. Add more by signing up later.");
  }
});
